---
name: Core Precision Dark
colors:
  surface: '#13131a'
  surface-dim: '#13131a'
  surface-bright: '#393841'
  surface-container-lowest: '#0e0d15'
  surface-container-low: '#1b1b23'
  surface-container: '#1f1f27'
  surface-container-high: '#2a2931'
  surface-container-highest: '#35343c'
  on-surface: '#e4e1ec'
  on-surface-variant: '#c7c4d6'
  inverse-surface: '#e4e1ec'
  inverse-on-surface: '#302f38'
  outline: '#918f9f'
  outline-variant: '#464554'
  surface-tint: '#c2c1ff'
  primary: '#c2c1ff'
  on-primary: '#1c0b9f'
  primary-container: '#5856d6'
  on-primary-container: '#e7e4ff'
  inverse-primary: '#4f4ccd'
  secondary: '#adc6ff'
  on-secondary: '#002e69'
  secondary-container: '#4b8eff'
  on-secondary-container: '#00285c'
  tertiary: '#ffb785'
  on-tertiary: '#502500'
  tertiary-container: '#a25100'
  on-tertiary-container: '#ffe1cf'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#0c006a'
  on-primary-fixed-variant: '#3631b4'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a41'
  on-secondary-fixed-variant: '#004493'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb785'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#13131a'
  on-background: '#e4e1ec'
  surface-variant: '#35343c'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  gutter: 24px
  margin-desktop: 40px
---

## Brand & Style

This design system is engineered for professional PC native environments where visual clarity and long-term focus are paramount. The brand personality is rooted in **Core Precision**: a philosophy of high-utility, zero-distraction, and rigorous accessibility. It targets power users, developers, and data analysts who require a high-performance interface that remains comfortable during extended sessions.

The aesthetic follows a **Refined High-Contrast Minimalism**. It rejects unnecessary decorative elements in favor of structural integrity and clear information hierarchy. By utilizing deep blacks and vibrant, high-energy accents, the system evokes a sense of technical mastery and "command-line" efficiency, translated into a modern graphical user interface. The emotional response is one of confidence, stability, and absolute legibility.

## Colors

The palette is optimized for WCAG AAA compliance, ensuring a contrast ratio of at least 7:1 for critical text and UI elements.

- **Foundations:** The canvas is pure `#000000` to maximize the OLED/LED black levels and reduce eye strain in low-light environments. Elevated surfaces use `#121212` to create subtle depth without sacrificing contrast.
- **Accents:** A vibrant dual-tone approach using **Electric Blue** for standard interactive elements and **Deep Violet** for primary global actions. These colors are calibrated to pop against the dark background while maintaining high visibility.
- **System States:** High-saturation tokens for Success (Emerald), Warning (Amber), and Error (Crimson) are used sparingly to ensure they command immediate attention.

## Typography

The typography system prioritizes extreme legibility for both English and Korean scripts. **Hanken Grotesk** serves as the primary typeface for its clean, geometric neo-grotesque forms that remain sharp at high resolutions.

- **Hierarchies:** Headlines utilize tighter tracking and heavier weights to anchor sections. Body text uses generous line heights (1.5x) to prevent "text-wall" fatigue in dark mode.
- **Mono-Integration:** **JetBrains Mono** is utilized for labels, metadata, and technical readouts. This distinction helps users instantly differentiate between "content" and "system data."
- **Korean Handling:** Ensure the font-weight for Korean characters matches the visual density of the Latin glyphs. For native app implementation, fall back to system-optimized sans-serifs (Pretendard or Apple SD Gothic Neo) if Hanken Grotesk is unavailable.

## Layout & Spacing

This design system employs a **Fixed-Fluid Hybrid Grid** optimized for 1920x1080 and larger desktop displays. 

- **The 4px Rhythm:** All spacing and component dimensions are multiples of 4px. This ensures a mathematical "snap" to the layout that reinforces the Core Precision brand.
- **Desktop Grid:** A 12-column grid with a 24px gutter. The maximum content width is capped at 1440px for readability, centering the application on ultra-wide monitors.
- **Density:** High density is preferred. Information is grouped in logical clusters using `16px` gaps, while major sections are separated by `48px` to provide visual breathing room.
- **Sidebars:** Persistent navigation rails are fixed at `72px` (collapsed) or `240px` (expanded).

## Elevation & Depth

In a pure black environment, depth is not created through heavy shadows but through **Tonal Layering** and **Luminous Outlines**.

- **Level 0 (Base):** Pure `#000000`. Used for the global background.
- **Level 1 (Surfaces):** `#121212`. Used for cards, sidebars, and toolbars. These surfaces use a subtle `1px` inner-stroke of `#FFFFFF` at 10% opacity to define their boundaries.
- **Level 2 (Popovers/Modals):** `#1E1E1E`. Highest surface elevation. These use a "Luminous Glow" shadow: a sharp 4px blur with 15% opacity using the primary accent color to indicate focus.
- **Interaction:** Hover states are indicated by increasing the surface brightness by 5% or adding a `2px` left-accent border.

## Shapes

The shape language balances professional rigidity with modern approachability. 

- **Base Radius:** `0.5rem (8px)` is the standard for buttons, input fields, and small containers. This provides a "Soft Tech" feel.
- **Large Radius:** `1rem (16px)` for major layout containers and cards.
- **Strictness:** Icons and decorative elements maintain sharp internal corners to contrast with the rounded external containers, reinforcing the precision narrative.

## Components

### Buttons
- **Primary:** Solid `#5856D6` background with white text. No border. On hover, background shifts to a brighter `#6E6CF5`.
- **Secondary:** Transparent background with a `1.5px` stroke of `#007AFF`.
- **Tertiary/Ghost:** No background or border. Text only in `#A1A1A1`, shifting to `#FFFFFF` on hover.

### Input Fields
- **Default State:** Background `#121212`, border `1px` solid `#2C2C2E`.
- **Focus State:** Border color shifts to `#007AFF` with a subtle outer glow of the same color at 20% opacity.
- **Accessibility:** Labels are always persistent above the field (never just placeholder text).

### Cards
- **Structure:** Background `#121212`. Corner radius `16px`. 
- **Content:** $24px$ padding. Titles in `headline-md`, body in `body-sm`.

### Lists & Tables
- **Rows:** Alternate background shading is avoided. Instead, `1px` horizontal dividers in `#1C1C1E` separate items.
- **Active State:** The entire row takes a subtle `#5856D6` (Violet) tint at 10% opacity with a solid `3px` vertical indicator on the left.

### Status Indicators (Chips)
- **Compact:** Height of `24px`, font size `label-md`. 
- **Contrast:** Chips use high-saturation text on a low-opacity version of the same color (e.g., Green text on 10% Green background) for maximum AAA readability.